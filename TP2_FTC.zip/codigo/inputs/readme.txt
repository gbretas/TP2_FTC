Gustavo Torres Bretas Alves
Maria Fernanda Oliveira Guimarães

Descrição das Estradas


```
S
(,),[,]
S:SS|()|(S)|[]|[S]
ENTRADAS
()
()()()
()()[][]
()[[()]]
FIM
Pode-se colocar qualquer coisa aqui.
```